package com.catchbest;

/**
 * @author:gmm
 * @date:2020/2/18
 * @类说明:
 */
public enum KSJ_SENSITIVITYMODE {
    KSJ_LOW,
    KSJ_MID,
    KSJ_HIGH,
    KSJ_HIGHER,
    KSJ_HIGHEST
}
