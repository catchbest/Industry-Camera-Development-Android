# KSJAndroidLibs
KSJApinew android libs repository

embedded in KSJApiNew and android_demo project
